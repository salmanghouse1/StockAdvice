import json
import csv
import requests
import argparse




#Given a filename, read a CSV and convert it to a Python data structure
#Build a method which returns the latest market price for holdings
#Build methods which calculate the book value, market value
#Build a method to convert the holding into CSV
#Build a method that writes to the output filename.
#As for writing files, use the tmp_path fixture that ships with pytest to write to temporary locations on the disk.


#Step 1 Ask for input stock symbol
#step 2 input should be written to csv file
#step 3 http request get the api json_data
#step 4 create variable and use value method and make calculation for current market value,
#the gain and loss for each holding a percentage of change

#Make sure to update requirements.txt and include any libraries required to build this project (e.g. requests, requests-mock) so they are available to Travis CI.



class Stocks:

    def __init__(self,filename,written_file="output.csv"):
        self.file=filename
        self.written_file=written_file

    def load_data_from_csv(self):
        if not self.file:
            print("Provide File Name CSV")
        else:
            with open(self.file,'r') as csvfile:
                csv_reader = csv.reader(csvfile)
                next(csv_reader)
                for line in csv_reader:
                    self.stocks_to_search_for=line[0]
                    return self.stocks_to_search_for

    def connection(self):
        self.response=requests.get("https://cloud.iexapis.com/v1")
        if self.response:
            return("Success in connecting")
        else:
            return("Error in connecting")



    def convert_data(self):
        self.json_data=json.loads(self.response.content)
        return self.json_data

    def write_data(self):
        if not self.json_data:
            print("Fetch Data Once again")
        else:
            with open(self.written_file,'w',newline="") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=["symbol","units","cost","latest_price","book_value","market_value","gain_loss","change"])
                writer.writeheader()
                writer.writerow({'symbol':self.stock_symbol,'units':self.quantity, 'cost':self.cost})
                csvfile.close()

    def caluclate(self):
        print("calculate")
